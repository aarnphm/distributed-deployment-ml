from .pickle import PickleArtifact  # noqa # pylint: disable=unused-import
from .json_file import JSONArtifact  # noqa # pylint: disable=unused-import
from .text_file import TextFileArtifact  # noqa # pylint: disable=unused-import
